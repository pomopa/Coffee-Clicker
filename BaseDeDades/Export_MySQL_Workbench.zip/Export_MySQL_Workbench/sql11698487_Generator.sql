-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: sql11.freesqldatabase.com    Database: sql11698487
-- ------------------------------------------------------
-- Server version	5.5.62-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Generator`
--

DROP TABLE IF EXISTS `Generator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Generator` (
  `idGenerator` int(11) NOT NULL AUTO_INCREMENT,
  `generatorsType` varchar(100) DEFAULT NULL,
  `numGenerator` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `incremental` double DEFAULT NULL,
  `production` double DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `gameName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idGenerator`),
  KEY `gameName` (`gameName`),
  CONSTRAINT `Generator_ibfk_1` FOREIGN KEY (`gameName`) REFERENCES `Game` (`gameName`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Generator`
--

LOCK TABLES `Generator` WRITE;
/*!40000 ALTER TABLE `Generator` DISABLE KEYS */;
INSERT INTO `Generator` VALUES (1,'Barista',8,9,1.07,128,'resources/barista.png','partida1'),(2,'Cascada de cafè',2,132,1.15,80,'resources/cascade.jpg','partida1'),(3,'Cafetera',6,3815,1.25,160,'resources/coffeemachine.png','partida1'),(4,'George Clooney',3,23526,1.33,50,'resources/george-clooney.jpg','partida1'),(5,'Granja',0,100000,1.45,200,'resources/farmer.png','partida1'),(6,'Fabrica',0,500000,1.6,550,'resources/factory.png','partida1'),(7,'Oompa Loompa',0,1000000,1.7,3000,'resources/wonka.png','partida1'),(8,'Central Perk',0,3000000,1.9,10000,'resources/centralperk.png','partida1'),(9,'Barista',0,5,1.07,4,'resources/barista.png','partida2'),(10,'Cascada de cafè',0,100,1.15,10,'resources/cascade.jpg','partida2'),(11,'Cafetera',0,1000,1.25,20,'resources/coffeemachine.png','partida2'),(12,'George Clooney',0,10000,1.33,50,'resources/george-clooney.jpg','partida2'),(13,'Granja',0,100000,1.45,200,'resources/farmer.png','partida2'),(14,'Fabrica',0,500000,1.6,550,'resources/factory.png','partida2'),(15,'Oompa Loompa',0,1000000,1.7,3000,'resources/wonka.png','partida2'),(16,'Central Perk',0,3000000,1.9,10000,'resources/centralperk.png','partida2');
/*!40000 ALTER TABLE `Generator` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-23  1:01:20
