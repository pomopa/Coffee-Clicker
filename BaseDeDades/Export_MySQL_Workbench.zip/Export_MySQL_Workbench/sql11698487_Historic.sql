-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: sql11.freesqldatabase.com    Database: sql11698487
-- ------------------------------------------------------
-- Server version	5.5.62-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Historic`
--

DROP TABLE IF EXISTS `Historic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Historic` (
  `idHistoric` int(11) NOT NULL AUTO_INCREMENT,
  `gameName` varchar(100) DEFAULT NULL,
  `numResources` bigint(20) DEFAULT NULL,
  `timeOnGame` int(11) DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idHistoric`),
  KEY `userName` (`userName`),
  KEY `gameName` (`gameName`),
  CONSTRAINT `Historic_ibfk_1` FOREIGN KEY (`userName`) REFERENCES `User` (`userName`) ON DELETE CASCADE,
  CONSTRAINT `Historic_ibfk_2` FOREIGN KEY (`gameName`) REFERENCES `Game` (`gameName`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Historic`
--

LOCK TABLES `Historic` WRITE;
/*!40000 ALTER TABLE `Historic` DISABLE KEYS */;
INSERT INTO `Historic` VALUES (1,'partida1',0,1,'David'),(2,'partida1',1554,60,'David'),(3,'partida1',1305,70,'David'),(4,'partida1',1324,71,'David'),(5,'partida1',2061,106,'David'),(6,'partida1',2099,107,'David'),(7,'partida1',946,115,'David'),(8,'partida1',989,116,'David'),(9,'partida1',1485,125,'David'),(10,'partida1',1533,126,'David'),(11,'partida1',1707,140,'David'),(12,'partida1',1769,141,'David'),(13,'partida1',2910,172,'David'),(14,'partida1',2992,173,'David'),(15,'partida1',2730,192,'David'),(16,'partida1',2842,193,'David'),(17,'partida1',6307,200,'David'),(18,'partida1',6419,201,'David'),(19,'partida1',4213,209,'David'),(20,'partida1',4357,210,'David'),(21,'partida1',2699,222,'David'),(22,'partida1',2883,223,'David'),(23,'partida1',6449,228,'David'),(24,'partida1',6633,228,'David'),(25,'partida1',4782,240,'David'),(26,'partida1',4782,241,'David'),(27,'partida1',5109,250,'David'),(28,'partida1',5109,251,'David'),(29,'partida1',12209,257,'David'),(30,'partida1',12477,258,'David'),(31,'partida1',5521,260,'David'),(32,'partida1',5801,261,'David'),(33,'partida1',16877,271,'David'),(34,'partida1',16877,271,'David'),(35,'partida1',5037,273,'David'),(36,'partida1',5037,274,'David'),(37,'partida1',11805,287,'David'),(38,'partida1',12313,288,'David'),(39,'partida1',7782,292,'David'),(40,'partida1',7782,293,'David'),(41,'partida1',18956,299,'David'),(42,'partida1',18956,300,'David'),(43,'partida1',8083,303,'David'),(44,'partida1',8656,304,'David'),(45,'partida1',16105,307,'David'),(46,'partida2',0,1,'David'),(47,'partida2',7,10,'David'),(48,'partida2',7,10,'David');
/*!40000 ALTER TABLE `Historic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-23  1:01:18
